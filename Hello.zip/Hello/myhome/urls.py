from django.contrib import admin
from django.urls import path
from myhome import views

urlpatterns = [
    path("",views.index, name='home'),
    path("videos",views.videos, name='about'),
    path("contact",views.contact, name='contect'),
]
