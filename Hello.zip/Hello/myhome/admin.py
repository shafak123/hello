from django.contrib import admin
from myhome.models import contact

# Register your models here.

admin.site.register(contact)