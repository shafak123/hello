import email
from os import name
from urllib import request
from django.http import HttpResponse
from django.shortcuts import render
# Create your views here.

def index(request):
    return render(request, 'index.html')

def videos(request):
    return render(request, 'videos.html')

def contact(request):
    if request.method =="POST":
     name = request.POST.get('name')
     email = request.POST.get('email')
     phone = request.POST.get('phone')
     contact = contact(name=name, email=email, phone=phone)
     contact.save()
 
    return render(request, 'contact.html')
    # return HttpResponse("this is contact us")